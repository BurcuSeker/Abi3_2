- LCSI folder contains the matlab scripts for processing the laser speckle data. It follows a certain order which is also indicated as in the file name (1, 2, 3..)
and each step will be run separately by the user). Project definition script automatically opens the scripts in Matlab. 
 - to test the LSCI scripts 2 example .dat files can be found in the data folder. This files can be used to test the script. 
 - .dat files were generated using Pimsoft software. After opening the recoding in Pimsoft software from the advanced functions the .dot files can be generated.
These .dat files were used then in Matlab to generate heatmaps and flow changes.