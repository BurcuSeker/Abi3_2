# How to Run the LSCI Processing Scripts

This package contains a **MATLAB-based pipeline** for processing **Laser Speckle Contrast Imaging (LSCI)** videos and extracting cerebral blood‑flow metrics. The scripts are numbered and designed to be run **in order**.

> If you just want to try it out quickly, there are two example `.dat` files in `data/` (one per group) and a `subjects.xlsx` to get you started.

---

## Requirements

- **MATLAB** R2020b or later (R2021a+ recommended)
- **Image Processing Toolbox**
- Optional (recommended): [`export_fig`](https://github.com/altmany/export_fig) for high‑quality figure export
- **PIMSoft / Perimed** acquisition software (source of `.dat` files). The `.dat` test files here were exported from PIMSoft’s Advanced functions.

> The scripts read **binary `.dat`** files as produced by PIMSoft and expect a **frames‑per‑second (fps)** value for each recording.

---

## Repository Layout (abridged)

```
.
├── data/
│   ├── GroupA/test_subject_A.dat        # example data
│   ├── GroupB/test_subject_B.dat        # example data
│   └── subjects.xlsx                    # subject table used by the pipeline
├── scripts/
│   ├── 01_setup_project.m               # set paths, default params (fps, folders, ROI grid)
│   ├── 02_find_datasets.m               # index all .dat files and build subjects table
│   ├── 03_define_ROI_prepare.m          # load each dataset and prep for manual ROI
│   ├── 04_define_ROI_manually.m         # interactive ROI editing + QC
│   ├── 05_average_epochs.m              # average stimulation epochs, generate maps
│   ├── 06_unblind_QC.m                  # merge blinded QC back to subjects
│   └── 07_summarize_results.m           # group‑level figures & ROI exports
├── utils/                               # helper functions (reading, plotting, ROI handling)
├── results/                             # outputs (created at runtime)
└── README.md / README.txt               # general info
```

---

## Quick Start (5 minutes)

1. **Unzip** the package and **open MATLAB** in the unzipped folder (project root).
2. In MATLAB, **add the repo to the path**:
   ```matlab
   addpath(genpath(pwd));
   ```
3. **Run the scripts in order** (see detailed steps below). A minimal test:
   - Run `scripts/01_setup_project.m` (check/adjust `fps`, paths).
   - Run `scripts/02_find_datasets.m` (indexes example `.dat` files under `data/`).
   - Run `scripts/03_define_ROI_prepare.m` then `scripts/04_define_ROI_manually.m` to define ROIs.
   - Run `scripts/05_average_epochs.m` to produce subject‑level maps/figures.
   - Optionally run `scripts/06_unblind_QC.m`, then `scripts/07_summarize_results.m`.

Outputs will be written to `results/` (and `results/QC/`).

---

## Step‑by‑Step Instructions

### 1) Project Setup — `scripts/01_setup_project.m`
- **What it does:** Clears workspace, adds paths, defines **base directories**, **fps**, and **ROI grid** parameters.
- **What to check/edit:**
  - `dirData` — where your raw `.dat` files live (defaults to `<repo>/data`).
  - `dirResults`, `dirQC` — output folders (created if missing).
  - `fps` — frames per second **per recording**. You can enter a global default here; per‑recording overrides are possible later in `subjects.xlsx`.
  - ROI grid: `gridWidth`, `roiCoordinates`, and optional `gridMask` (e.g., via `create_spherical_mask`).
- **How to run:**
  ```matlab
  run('scripts/01_setup_project.m')
  ```

### 2) Find Datasets — `scripts/02_find_datasets.m`
- **What it does:** Recursively searches `dirData` for `*.dat`, builds a table with `folder`, `group`, `fnameDat`, `fps`, and initial **exclusion flags** (`exclude`, `excludeStimulation`).
- **Outputs:** Writes/updates `data/subjects.xlsx`.
- **Tips:** Organize your data as `data/<GroupName>/<subject_or_file>.dat` for automatic **group** inference.
- **How to run:**
  ```matlab
  run('scripts/02_find_datasets.m')
  ```

### 3) Prepare ROI Definition — `scripts/03_define_ROI_prepare.m`
- **What it does:** Loads each dataset (read‑only) and displays raw perfusion frames using `utils/visualize_perfusion_raw.m`.
- **Goal:** Sanity‑check the data and get ready for manual ROI placement.
- **How to run:**
  ```matlab
  run('scripts/03_define_ROI_prepare.m')
  ```
- **Notes:** Closes each figure after review to advance to the next file.

### 4) Manual ROI & QC — `scripts/04_define_ROI_manually.m`
- **What it does:** Opens each dataset with interactive ROI tools and QC forms (`manage_ROI_editing`, `visualize_perfusion_raw`). Allows placing **spherical ROIs**, defining **stimulation windows**, and setting **exclusion** flags.
- **State saving:** Progress is saved alongside `subjects.xlsx` (a `.mat` with the editing state).
- **How to run:**
  ```matlab
  run('scripts/04_define_ROI_manually.m')
  ```

### 5) Average Stimulation Epochs — `scripts/05_average_epochs.m`
- **What it does:** For each dataset **not excluded**, computes and saves **subject‑level averages** within a stimulation time window, generating **flow maps** and **summary figures**.
- **Key parameters in the script:**
  - `outputImageSize` — resized image resolution (e.g., `120` px).
  - `wndStimDuration` — time window **within** the stimulation period to average, in seconds (e.g., `[10, 30]`).
- **How to run:**
  ```matlab
  run('scripts/05_average_epochs.m')
  ```

### 6) Unblind QC (optional) — `scripts/06_unblind_QC.m`
- **What it does:** If you used **blinded QC**, this step merges blinded QC results (from `<subjects>_rnd.xlsx`) back into the main `subjects.xlsx` using a **random ID** mapping.
- **How to run:**
  ```matlab
  run('scripts/06_unblind_QC.m')
  ```

### 7) Summarize Results — `scripts/07_summarize_results.m`
- **What it does:** Produces **group‑level** figures and exports per‑ROI time courses and summary statistics.
- **Key parameters:** `groupNames`, `outputImageSize`, `nEpochsMax`, color limits (`colorScaleLimits`), `cmap`, `nContours`, `maskBorders`.
- **How to run:**
  ```matlab
  run('scripts/07_summarize_results.m')
  ```

---

## What Comes Out

- **Subject‑level** perfusion maps/PNGs and MAT files
- **QC spreadsheets** and blinded/unblinded subject sheets
- **Group‑level** heatmaps (PNG), ROI boxplots, and exported ROI timecourses suitable for stats in R/Python/Matlab
- All saved under `results/` (and subfolders like `results/QC/`).

---

## Tips & Troubleshooting

- **`fps` wrong → timing off:** Update `fps` in `subjects.xlsx` (or in step 1) and rerun steps 3–5.
- **Figures don’t export:** Install `export_fig` and ensure it’s on the MATLAB path (`addpath(genpath('<path-to-export_fig>'))`).
- **Large `.dat` files:** Close figures promptly in steps 3–4. Consider running from SSD storage.
- **ROI grid looks odd:** Check `gridWidth` and `roiCoordinates` in step 1. For masks, use `utils/create_spherical_mask.m`.
- **Excluding bad trials:** Use `exclude` or `excludeStimulation` columns in `subjects.xlsx` (set to `1` to omit).

---

## Example One‑Liner Session

```matlab
addpath(genpath(pwd));
run('scripts/01_setup_project.m');
run('scripts/02_find_datasets.m');
run('scripts/03_define_ROI_prepare.m');
run('scripts/04_define_ROI_manually.m');
run('scripts/05_average_epochs.m');
% Optional:
% run('scripts/06_unblind_QC.m');
run('scripts/07_summarize_results.m');
```

---

## Citation

If this pipeline contributes to a publication, please cite your GitHub release and acknowledge the LSCI pipeline authors.
