# LSCI Analysis Pipeline for Cerebral Blood Flow

This repository contains MATLAB scripts for analyzing Laser Speckle Contrast Imaging (LSCI) data related to cerebral blood flow. The pipeline is generalized for use in different studies and groups.

## 🧪 Overview

This pipeline:
- Detects and organizes `.dat` imaging data
- Allows manual ROI definition and QC
- Averages signal timecourses across epochs
- Generates subject-level and group-level heatmaps
- Outputs ROI time courses for statistical analysis

## 🗂 Repository Structure

```
LSCI_Analysis/
├── data/                  # Contains test datasets and subject metadata
│   ├── GroupA/test_subject_A.dat
│   ├── GroupB/test_subject_B.dat
│   └── subjects.xlsx
├── scripts/               # All analysis scripts in order
├── utils/                 # Helper functions
├── results/               # Output folder (ignored by Git)
├── README.md              # You're here!
├── LICENSE                # MIT or similar
└── .gitignore             # Ignores .fig/.asv/temp files
```

## 🔁 Workflow

Run these scripts in order:

1. `01_setup_project.m`
2. `02_find_datasets.m`
3. `03_define_ROI_prepare.m`
4. `04_define_ROI_manually.m`
5. `05_average_epochs.m`
6. `06_unblind_QC.m`
7. `07_summarize_results.m`

> For first-time users, test the pipeline using the sample `.dat` files provided in `data/`.

## 📁 Data Format Requirements

This pipeline requires binarized `.dat` files exported from your LSCI acquisition software. These files must include raw variance and intensity frames.

- The included test `.dat` files are fake and for demonstration only.
- Each `.dat` file must be organized by group into subfolders.
- A matching `subjects.xlsx` file should list each file's folder, name, and `fps`.

### 📦 Want to Use Real Data?

Upload your `.dat` files to:
```
data/GroupX/your_subject_file.dat
```

Then update `subjects.xlsx` to include these files.

#### Downloadable Data (optional)

If you're using this pipeline and need real data for testing:

➡️ [https://your-lab-cloud.org/your_dataset.zip](#) ← Replace with actual link

## 🧰 Requirements

- MATLAB R2021a or later (recommended)
- Image Processing Toolbox
- Optional: `export_fig` (for high-quality figure exports)

## 📄 License

MIT License

## 🙌 Acknowledgements

This pipeline was originally developed for cerebral blood flow studies using LSCI.  
If you use it in your research, please cite appropriately.
